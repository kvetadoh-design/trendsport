# TrendSpot — bezplatný startovací web

Moderní jednostránkový web v češtině pro nápad na propojení značek a tvůrců. Je responzivní, bez externích knihoven a bez placených služeb.

## Jak ho otevřít
1. Rozbal ZIP.
2. Otevři `index.html` v prohlížeči.

## Jak ho zdarma zveřejnit
Můžeš použít GitHub Pages nebo Netlify (bezplatný tarif se může měnit). Nahraj `index.html` jako statický web. Vlastní doména obvykle stojí peníze, takže začni s bezplatnou adresou poskytovatele.

## Důležité před zveřejněním
- V `index.html` vyhledej `kontakt@trendspot.cz` a nahraď to svou funkční e-mailovou adresou.
- Ukázkové kampaně jsou označené jako ukázky — nejsou to skutečné nabídky.
- Formulář jen připraví e-mail přes `mailto:`; nemá databázi ani neposílá data na server.
- Doplň pravdivé informace o provozovateli a zásady ochrany osobních údajů, pokud budeš sbírat kontakty.
- Nezaručuj výdělky. Reklamní spolupráce řádně označuj a domlouvej si práva k obsahu.
- Nepoužívej loga, fotky ani reklamy cizích značek bez svolení.

## Nápad na první týden
1. Vyber si jednu kategorii (např. gaming nebo móda).
2. Oslov malé lokální značky a tvůrce s konkrétním návrhem spolupráce.
3. Přidej jen nabídky, které jsou skutečné a odsouhlasené.
4. Zjišťuj, jestli lidé na webu opravdu mají zájem, než začneš přidávat složitější funkce.
